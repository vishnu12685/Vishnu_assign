import React, { useEffect } from 'react'
import './App.css';
import TopNav from './components/TopNav/TopNav';
import DashView from './components/DashBoard/DashView';
import { useDispatch, useSelector} from 'react-redux'
import { fetchAllData } from './Actions/Main';
import Loading from './components/Loading/Loading';

const App = () => {
  const dispatch = useDispatch();
  const {allTickets} = useSelector(state => state.DataReducer);
   
  useEffect(() => {
    dispatch(fetchAllData());
  }, [dispatch])

  return allTickets ? (
    <div >
      <TopNav/>
      
      <DashView/>
    </div>
  ) : <Loading/>
}

export default App